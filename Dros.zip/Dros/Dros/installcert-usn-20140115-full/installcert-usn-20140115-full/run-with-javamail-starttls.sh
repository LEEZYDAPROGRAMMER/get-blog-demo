#!/bin/sh
#------------------------------------------------------------------------------
# Run InstallCert against a POP3, IMAP or SMTP server using STARTTLS.
#
# The 'installcert-usn-20140115.jar' file is expected to be found in the
# current directory.
#------------------------------------------------------------------------------

# JavaMail .jar location: to be amended
#javamail_jar=/Users/ushakov/-work/JavaTools/javamail-1.5.1/javax.mail.jar

# check JavaMail .jar location being defined
if [ -z "$javamail_jar" ]
  then
    printf "Please first edit this script and uncomment/amend the line"
    printf " that defines the 'javamail_jar' variable,"
    echo " so to reflect your JavaMail library location."
    printf "See https://java.net/projects/javamail/pages/Home"
    echo " for JavaMail download."
        exit 1
  fi

# check command line arguments
if [ $# -lt 1 -o $# -gt 2 ]
  then
    echo "Usage:"
    echo "  $0 host[:port] [truststore_password]"
    echo "Default port is 443."
    echo "Default truststore password is \"changeit\" as per JSSE convention."
    exit 1
  fi

# construct the classpath and run
cp="installcert-usn-20140115.jar:$javamail_jar"
java -cp "$cp" usn.net.ssl.util.InstallCert "$@"
