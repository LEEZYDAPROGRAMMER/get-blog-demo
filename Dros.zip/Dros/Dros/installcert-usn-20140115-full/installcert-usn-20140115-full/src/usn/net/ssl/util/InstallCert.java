/*
 * Copyright 2006 Sun Microsystems, Inc.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Sun Microsystems nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package usn.net.ssl.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.SocketException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.Vector;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import javax.naming.ldap.Rdn;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import sun.security.provider.certpath.SunCertPathBuilderException;
import sun.security.validator.ValidatorException;

/**
 * <p>A program to obtain SSL certificate(s) from a host and save them to a
 *     keystore and optionally install them in local JSSE storage; the program
 *     collects SSL/TLS certificates from plain SSL/TLS hosts, and also from
 *     hosts that operate with STARTTLS extension for LDAP, SMTP, POP3 and
 *     IMAP.</p>
 * <p><b>Original article:</b> <a
 *     href="http://blogs.sun.com/andreas/entry/no_more_unable_to_find"
 *     >http://blogs.sun.com/andreas/entry/no_more_unable_to_find</a><br>
 *     <b>Original source:</b> <a
 *     href="http://blogs.sun.com/andreas/resource/InstallCert.java"
 *     >http://blogs.sun.com/andreas/resource/InstallCert.java</a><br>
 *     <b>Author:</b> Andreas Sterbenz, 2006</p>
 * <p><b>Currently available at:</b> <a
 *     href="https://java.net/projects/javamail/pages/InstallCert"
 *     >https://java.net/projects/javamail/pages/InstallCert</a><br>
 *     <b>Current Google Code branch as web page:</b> <a
 *     href="http://code.google.com/p/java-use-examples/source/browse/trunk/src/com/aw/ad/util/InstallCert.java"
 *     >http://code.google.com/p/java-use-examples/source/browse/trunk/src/com/aw/ad/util/InstallCert.java</a
 *     ><br>
 *     <b>Current Google Code branch as Java code:</b> <a
 *     href="http://java-use-examples.googlecode.com/svn/trunk/src/com/aw/ad/util/InstallCert.java"
 *     >http://java-use-examples.googlecode.com/svn/trunk/src/com/aw/ad/util/InstallCert.java</a
 *     ><br>
 *     <b>Source path in Google Code repository:</b> <code>svn/ trunk/ src/ com/
 *     aw/ ad/ util/ InstallCert.java</code></p>
 * <p><b>Approach to STARTTLS with JavaMail</b>: Eugen Kuleshov and Dmitry I.
 *     Platonoff, JavaWorld.com, August 31, 2001<br>
 *     <a href="http://www.javaworld.com/javatips/jw-javatip115.html">Java Tip
 *     115: Secure JavaMail with JSSE</a></p>
 * <p><b>Merged together by:</b> Sergey Ushakov (usn), 2012&ndash;2013</p>
 * <p><b>Use without STARTTLS extension for SMTP, POP3 and IMAP
 *     protocols:</b><br>
 *     <code>java -jar installcert-usn-....jar {@literal <host>[:<port>]
 *     [<truststore_password>]}</code><br>
 *     Default port is 443.<br>
 *     Default truststore password is "changeit" as per JSSE convention.<br>
 *     The program uses a keystore file named "extracerts" in the current
 *     directory to store the new certificates, and also attempts to add them to
 *     the standard system keystore <code>jssecacerts</code>, see <a
 *     href="http://docs.oracle.com/javase/7/docs/technotes/guides/security/jsse/JSSERefGuide.html#X509TrustManager"
 *     >http://docs.oracle.com/javase/7/docs/technotes/guides/security/jsse/JSSERefGuide.html#X509TrustManager</a
 *     >.</p>
 * <p><b>Example:</b><br>
 *     <code>java -jar installcert-usn-20140115.jar
 *     ecc.fedora.redhat.com</code></p>
 * <p><b>Use with STARTTLS extension for SMTP, POP3 and IMAP protocols:</b><br>
 *     <i>on Windows:</i><br>
 *     <code>java -cp installcert-usn-....jar;.../javax.mail.jar 
 *     usn.net.ssl.util.InstallCert {@literal <host>[:<port>]
 *     [<password>]}</code><br>
 *     <i>on *ix:</i><br>
 *     <code>java -cp installcert-usn-....jar:.../javax.mail.jar
 *     usn.net.ssl.util.InstallCert {@literal <host>[:<port>]
 *     [<password>]}</code><br>
 *     Be sure to provide the real path to your local copy of
 *     <code>javax.mail.jar</code> :)</p>
 * <p>See Oracle <a
 *     href="http://www.oracle.com/technetwork/java/sslnotes-150073.txt"
 *     >Notes for use of SSL with JavaMail</a>.</p>
 */
public class InstallCert
  {
    final static String PROGRAM_TERMINATED = "Program terminated.";

    final static String EXTRA_CERTS_FILE_NAME = "extracerts";

    // this one is needed here to allow being shared with embedded classes
    static SSLContext context;

    // this one is needed here to allow the program arguments be accessible by
    // error handler(s)
    static String [] savedArgs;


    // constructor made private to avoid being mentioned in the javadocs
    private InstallCert
        ()
      {
      } // InstallCert


    /**
     * Run the program from command line.
     * 
     * @param args command line arguments as: <code>{@literal <host>[:<port>]
     *             [<truststore_password>]}</code>
     * @throws Exception
     */
    public static void main
        (String [] args)
        throws Exception
      {
        // make a copy of command line arguments for error handlers...
        savedArgs = args;
        // and one more for convenient processing of optional command line
        //  arguments
        Vector <String> argsCopy = new Vector <String> (Arrays.asList (args));

        // handle command line arguments
        String host = null;
        int port = 0;
        char [] password = null;
        if (argsCopy.size () < 1)
          {
            terminateWithUsageMessage ();
          }
        // this is the place to check for optional prepended arguments and
        // process/remove them, like this:
        //   if (argsCopy.get (0).equals ("-something"))
        //     {
        //       // ... do something with the argument
        //       argsCopy.remove (0);
        //     }
        // check for excessive arguments
        if (argsCopy.size () > 2)
          {
            terminateWithUsageMessage ();
          }
        // handle standard arguments
        String [] c = argsCopy.get (0).split (":");
        host = c [0];
        port = (c.length < 2) ? 443 : Integer.parseInt (c [1]);
        String p = (argsCopy.size () < 2) ? "changeit" : argsCopy.get (1);
        password = p.toCharArray ();

        // obtain a KeyStore instance for certificates known to the system
        KeyStore ksKnown = KeyStore.getInstance (KeyStore.getDefaultType ());
        char SEP = File.separatorChar;
        File systemSecurityDir = new File (System.getProperty ("java.home") +
                                           SEP + "lib" + SEP + "security");
        File file = new File (systemSecurityDir, "jssecacerts");
        if (!file.exists ())
          {
            file = new File (systemSecurityDir, "cacerts");
          }
        System.out.println ("... loading system truststore from '" +
                            file.getCanonicalPath () + "' ...");
        InputStream in = new FileInputStream (file);
        ksKnown.load (in, password);
        in.close ();

        // obtain an extra KeyStore instance for collected certificates
        KeyStore ksNew = KeyStore.getInstance (KeyStore.getDefaultType ());
        file = new File (EXTRA_CERTS_FILE_NAME);
        if (file.exists ())
            {
              System.out.println ("... loading extra truststore from '" +
                                  file.getCanonicalPath () + "' ...");
              in = new FileInputStream (file);
              ksNew.load (in, password);
              in.close ();
            }
          else
            {
              System.out.println
                ("... creating extra truststore as a new one ...");
              ksNew.load (null, password);
            }

        // obtain an instance of a TLS SSLContext
        context = SSLContext.getInstance ("TLS");

        // obtain a TrustManagerFactory instance
        TrustManagerFactory tmf =
          TrustManagerFactory.getInstance
            (TrustManagerFactory.getDefaultAlgorithm ());

        // initialize it with known certificate data
        tmf.init (ksKnown);

        // obtain default TrustManager instance
        X509TrustManager defaultTrustManager =
          (X509TrustManager) tmf.getTrustManagers () [0];

        SavingTrustManager tm =
            new SavingTrustManager (defaultTrustManager, ksNew);
        context.init (null, new TrustManager [] { tm }, null);
        SSLSocketFactory factory = context.getSocketFactory ();

        System.out.println ("... opening connection to " + host + ":" + port +
                            " ...");
        SSLSocket sslSocket = null;
        try
          {
            sslSocket = (SSLSocket) factory.createSocket (host, port);
          }
        catch (java.net.ConnectException e)
          {
            terminateWithErrorMessage (e, "connecting to remote host");
          }
        sslSocket.setSoTimeout (10000);
        System.out.println ("... starting SSL handshake ...");
        try
          {
            sslSocket.startHandshake ();
            System.out.println ("No errors, certificate is already trusted.");
          }
        // SMTP/STARTTLS and IMAP/STARTTLS servers seem tending to yield an
        //   SSLException with
        //   "Unrecognized SSL message, plaintext connection?" message.
        // LDAP/STARTTLS servers seem tending to yield an
        //   SSLHandshakeException with nested EOFException or a
        //   SocketException with "Connection reset" message.
        // Thus three distinct cases for considering a STARTTLS extension below
        catch (SSLHandshakeException e)
          {
            if (e.getCause ().getClass ().equals (ValidatorException.class) &&
                e.getCause ().getCause ().getClass ().equals
                  (SunCertPathBuilderException.class))
                {
                  // this is the standard case: looks like we just got a
                  // previously unknown certificate, so report it and go
                  // ahead...
                  System.out.println (e.toString ());
                }
              else if (e.getCause ().getClass ().getName ().equals
                         ("java.io.EOFException"))
                // "Remote host closed connection during handshake"
                {
                  // close the unsuccessful SSL socket
                  sslSocket.close ();
                  // consider trying STARTTLS extension over ordinary socket
                  if (!Starttls.consider (host, port))
                    {
                      // Starttls.consider () is expected to have reported
                      // everything except the final good-bye...
                      System.out.println (PROGRAM_TERMINATED);
                      System.exit (1);
                    }
                }
              else
                {
                  e.printStackTrace ();
                  System.exit (1);
                }
          }
        catch (SSLException e)
          {
            if (e.getMessage ().equals
                  ("Unrecognized SSL message, plaintext connection?"))
                {
                  System.out.println ("ERROR on SSL handshake: " +
                                      e.toString ());
                  sslSocket.close ();
                  // consider trying STARTTLS extension over ordinary socket
                  if (!Starttls.consider (host, port))
                    {
                      // Starttls.consider () is expected to have reported
                      // everything except the final good-bye...
                      System.out.println (PROGRAM_TERMINATED);
                      System.exit (1);
                    }
                }
              else
                {
                  e.printStackTrace ();
                  System.exit (1);
                }
          }
        catch (SocketException e)
          {
            if (e.getMessage ().equals ("Connection reset"))
                  {
                    System.out.println ("ERROR on SSL handshake: " +
                                        e.toString ());
                    sslSocket.close ();
                    // consider trying STARTTLS extension over ordinary socket
                    if (!Starttls.consider (host, port))
                      {
                        // Starttls.consider () is expected to have reported
                        // everything except the final good-bye...
                        System.out.println (PROGRAM_TERMINATED);
                        System.exit (1);
                      }
                  }
                else
                  {
                    e.printStackTrace ();
                    System.exit (1);
                  }
          }
        finally
          {
            if (!sslSocket.isClosed ())
              {
                sslSocket.close ();
              }
          }

        // get the full set of new accumulated certificates as an array
        X509Certificate [] chain =
          tm.newCerts.toArray (new X509Certificate [0]);

        // an empty set for certificates to be selected for saving 
        Set <X509Certificate> certsToSave = new HashSet <X509Certificate> ();

        // display the list of obtained certificates, inspect them and
        // interrogate the user whether to save them
        if (chain.length > 0)
          {
            System.out.println ();
            System.out.println ("Server sent " + chain.length +
                                " certificate(s):");
            MessageDigest sha1 = MessageDigest.getInstance ("SHA1");
            MessageDigest md5 = MessageDigest.getInstance ("MD5");
            for (int i = 0; i < chain.length; i++)
              {
                X509Certificate cert = chain [i];
                System.out.println ();
                System.out.println (" " + (i + 1) + " Subject " +
                                    cert.getSubjectDN ());
                System.out.println ("   Issuer  " + cert.getIssuerDN ());
                System.out.println ("   CN      " + getCommonName (cert));
                sha1.update (cert.getEncoded ());
                System.out.println ("   sha1    " +
                                    toHexString (sha1.digest ()));
                md5.update (cert.getEncoded ());
                System.out.println ("   md5     " +
                                    toHexString (md5.digest ()));
                System.out.println ();
                if (ksKnown.getCertificateAlias (cert) != null)
                    {
                      System.out.println ("Certificate already known to the" +
                                          " system truststore.");
                    }
                  else if (ksNew.getCertificateAlias (cert) != null)
                    {
                      System.out.println ("Certificate already known to the" +
                                          " extra truststore.");
                    }
                  else
                    {
                      String userResponse =
                          ask ("Add this certificate to the extra truststore" +
                               " [y/n] ? ");
                      if ((userResponse.length () > 0) &&
                          userResponse.substring (0, 1)
                            .toUpperCase (Locale.ENGLISH).equals ("Y"))
                          {
                            certsToSave.add (cert);
                            System.out.println
                                ("Certificate marked to be added.");
                          }
                        else
                          {
                            System.out.println ("Certificate skipped.");
                          }
                    }
              }
          }

        // save the new certificates approved by the user
        if (!certsToSave.isEmpty ())
            {
              // assign aliases using host name and certificate common name
              for (X509Certificate cert : certsToSave)
                {
                  String alias = host + " - " + getCommonName (cert);
                  ksNew.setCertificateEntry (alias, cert);
                  ksKnown.setCertificateEntry (alias, cert);
                  System.out.println ();
                  System.out.println (cert);
                  System.out.println ();
                  System.out.println
                    ("Certificate will be added using alias '" + alias + "'.");
                }

              // save them to the extra truststore for certificates known just
              // locally
              System.out.println ();
              System.out.println
                ("... adding certificate(s) to the extra truststore ...");
              OutputStream out = new FileOutputStream (EXTRA_CERTS_FILE_NAME);
              ksNew.store (out, password);
              out.close ();
              System.out.println ();
              System.out.println ("New certificates saved to truststore '" +
                                  EXTRA_CERTS_FILE_NAME +
                                  "' in the current directory.");

              // save them to the system "jssecacerts" truststore
              File jssecacertsFile =
                  new File (systemSecurityDir, "jssecacerts");
              out = new FileOutputStream (jssecacertsFile);
              ksKnown.store (out, password);
              out.close ();
              System.out.println ();
              System.out.println ("New certificates also saved to system " +
                                  "truststore '" +
                                  jssecacertsFile.getCanonicalPath () +
                                  "'.");
            }
          else
            {
              System.out.println ();
              System.out.println ("No new certificates found to be added " +
                                  "to the extra truststore.");
            }
      } // main


    static void terminateWithUsageMessage ()
      {
        System.out.println
          ("Usage: java [-cp ." + System.getProperty ("path.separator") +
             "javax.mail.jar] -jar installcert-usn-....jar <host>[:<port>] " +
             "[<truststore_password>]\n" +
           "Default port is 443.\n" +
           "Default truststore password is 'changeit'.");
        System.exit (1);
      } // terminateWithUsageMessage


    static void terminateWithErrorMessage
        (Throwable e, String context)
      {
        System.out.println ("ERROR " + context + ": " + e.toString ());
        System.out.println (PROGRAM_TERMINATED);
        System.exit (1);
      } // terminateWithErrorMessage


    static String joinStringArray
        (String [] array, String delimiter)
      {
        StringBuilder sb = new StringBuilder ();
        for (String s : array)
          {
            if (sb.length () > 0)
              {
                sb.append (delimiter);
              }
            sb.append (s);
          }
        return sb.toString ();
      } // joinStringArray


    static String toHexString
        (byte [] bytes)
      {
        StringBuilder sb = new StringBuilder (bytes.length * 3);
        for (int b : bytes)
          {
            sb.append (String.format ("%02x ", b & 0xff));
          }
        return sb.toString ();
      } // toHexString


    static String ask
        (String prompt)
        throws IOException
      {
        System.out.print (prompt);
        BufferedReader stdinReader =
          new BufferedReader (new InputStreamReader (System.in));
        String line = stdinReader.readLine ().trim ();
        return line;
      } // ask


    static String getCommonName
        (X509Certificate cert)
        throws InvalidNameException
      {
        // use LDAP API to parse the certifiate Subject :)
        // see http://stackoverflow.com/a/7634755/972463
        LdapName ldapDN =
            new LdapName (cert.getSubjectX500Principal ().getName ());
        String cn = "";
        for (Rdn rdn : ldapDN.getRdns ())
          {
            if (rdn.getType ().equals ("CN"))
              {
                cn = rdn.getValue ().toString ();
              }
          }
        return cn;
      }  // getCommonName

    // -- class SavingTrustManager ---------------------------------------------

    /**
     * An {@link X509TrustManager} subclass that accumulates unknown
     * certificates in order to allow saving them afterwards.
     */
    protected static class SavingTrustManager implements X509TrustManager
      {
        protected X509TrustManager parentTm;
        protected Set <X509Certificate> allAccumulatedCerts =
          new HashSet <X509Certificate> ();
        protected Set <X509Certificate> newCerts =
          new HashSet <X509Certificate> ();

        /**
         * The constructor.
         * 
         * @param parentTm an {@link X509TrustManager} instance to do the
         *                 standard part of certificates validation job
         * @param ksExtra a {@link KeyStore} instance that contains previously
         *                accumulated certificates
         * @throws KeyStoreException 
         */
        SavingTrustManager
            (X509TrustManager parentTm,
             KeyStore ksExtra)
            throws KeyStoreException
          {
            if (parentTm == null)
                {
                  throw new IllegalArgumentException
                              ("Parent trust manager cannot be null.");
                }
              else
                {
                  this.parentTm = parentTm;
                }
            if (ksExtra != null)
              {
                Enumeration <String> ksAliases = ksExtra.aliases ();
                while (ksAliases.hasMoreElements ())
                  {
                    String alias = ksAliases.nextElement ();
                    this.allAccumulatedCerts.add
                      ((X509Certificate) ksExtra.getCertificate (alias));
                  }
              }
          } // SavingTrustManager

        // .. javax.net.ssl.X509TrustManager methods ...........................

        @Override
        public void checkClientTrusted
            (X509Certificate [] chain, String authType)
            throws CertificateException
          {
            throw new UnsupportedOperationException ();
          } // checkClientTrusted


        @Override
        public void checkServerTrusted
            (X509Certificate [] chain, String authType)
            throws CertificateException
          {
            CertificateException exceptionToRethrow = null;
            // check the certificate chain against the system truststore
            try
              {
                parentTm.checkServerTrusted (chain, authType);
              }
            catch (CertificateException e)
              // the certificate chain was found not trusted
              {
                // check if the first certificate in the chain is not known yet
                //   to the local certificate storage
                if (!this.allAccumulatedCerts.contains (chain [0]))
                  {
                    // save the exception to be re-thrown later if not known
                    exceptionToRethrow = e;
                    // save the full chain to both local accumulators
                    for (X509Certificate cert : chain)
                      {
                        this.allAccumulatedCerts.add (cert);
                        this.newCerts.add (cert);
                      }
                  }
              }
            // check and re-throw the exception if any 
            if (exceptionToRethrow != null)
              {
                throw exceptionToRethrow;
              }
          } // checkServerTrusted


        @Override
        public X509Certificate [] getAcceptedIssuers
            ()
          {
            return this.parentTm.getAcceptedIssuers ();
          } // getAcceptedIssuers

      } // class SavingTrustManager

  } // class InstallCert

