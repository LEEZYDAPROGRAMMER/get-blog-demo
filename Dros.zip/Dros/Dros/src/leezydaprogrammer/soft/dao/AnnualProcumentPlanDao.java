/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leezydaprogrammer.soft.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import leezydaprogrammer.soft.pojo.TransAPP;

/**
 *
 * @author thand
 */
public class AnnualProcumentPlanDao 
{
      private Connection connection;
    private Statement statement;
      
    //open
    public void openDbase() throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/drosdb?zeroDateTimeBehavior=convertToNull", "leezy","12345");
        statement = connection.createStatement();        
    }
      //insert
     public int insert(TransAPP app) throws SQLException
    {
        
      String sql="INSERT INTO `annual procument plan`(`Project Number`,`Project Description`,`Estimated Value`,`Procument Method`,`PPPFA Evaluation Criteria`,`Approved By`,`Reviewed`,`Business Unit`,`Requested Date`)" + " values('"+app.getProjectNumber()+"','"+app.getProjectDescription()+"','"+app.getEstimatedValue()+"','"+app.getProcumentMethod()+"','"+app.getEvaluationCriteria()+"','"+app.getApprovedBy()+"','"+app.getReviewed()+"','"+app.getBusinessUnit()+"','"+app.getRequestedDate()+"')";
      
      return statement.executeUpdate(sql);
    }
     
       //search 
     public TransAPP getProcumentPlan(String projectNumber) throws SQLException
    {
        TransAPP app = null;
        String sql = "Select * from `annual procument plan` where `Project Number` = '" + projectNumber+"'";
        ResultSet rs = statement.executeQuery(sql);
        
        while(rs.next())
        {
            app = new TransAPP(rs.getString(1),rs.getString(2),rs.getDouble(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9));
           
        }
        
        return app;
    }
    //view all
     public Vector<TransAPP> getAnnualProcumentPlan() throws SQLException
    {
       
        Vector<TransAPP> listApp = new Vector<TransAPP>();
        String sql = "Select * from `annual procument plan` where 1";
        ResultSet rs = statement.executeQuery(sql);
        
        while(rs.next())
        {
         TransAPP  app = new TransAPP(rs.getString(1),rs.getString(2),rs.getDouble(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9));
            
        
            listApp.add(app); 
        }
        return listApp;
    }
     
    //delete
      public int delete(String projectNumber) throws SQLException
    {
        String sql = "delete from `annual procument plan` where `Project Number`='"+projectNumber+"'";
         return statement.executeUpdate(sql);
    
    }
      //update review
     public int Approve(String projectNumber) throws SQLException
    {
        String approve="yes";
        String sql = "update `annual procument plan` set `Reviewed` = '"+ approve +"' where `Project Number` ='"+projectNumber+"'";
         return statement.executeUpdate(sql);
    
    }
     //reviewedPlans
      public Vector<TransAPP> getReviewedPlans() throws SQLException
    {
        
        Vector<TransAPP> listApp = new Vector<TransAPP>();
        String sql = "Select * from `annual procument plan` where `Reviewed` ='yes'";
        ResultSet rs = statement.executeQuery(sql);
        
        while(rs.next())
        {
         TransAPP  app = new TransAPP(rs.getString(1),rs.getString(2),rs.getDouble(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9));
           listApp.add(app);
        }
        
        return listApp;
    }
//close
     public void close() throws SQLException
    {
        statement.close();
        connection.close();
    }
}
