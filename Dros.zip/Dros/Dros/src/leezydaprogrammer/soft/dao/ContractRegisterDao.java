/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leezydaprogrammer.soft.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import leezydaprogrammer.soft.pojo.TransCR;

/**
 *
 * @author thand
 */
public class ContractRegisterDao 
{
    private Connection connection;
    private Statement statement;
      
    //open
    public void openDbase() throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/drosdb", "leezy","12345");
        statement = connection.createStatement();        
    }
      //insert
     public int insert(TransCR cr) throws SQLException
    {
        
      String sql="INSERT INTO `contract register`(`Contract Name`,`Type of Goods and Services`,`Responsible Executive`,`Start Date`,`End Date`,`Contract Amount`,`Amount Paid`)" + " values('"+cr.getContractName()+"','"+cr.getTypeOfGS()+"','"+cr.getResponsibleExecutive()+"','"+cr.getStartDate()+"','"+cr.getEndDate()+"','"+cr.getContractAmount()+"','"+cr.getAmountPaid()+"')";
      
      return statement.executeUpdate(sql);
    }
     
       //search Contract
     public TransCR getContract(String contractName) throws SQLException
    {
        TransCR cr = null;
        String sql = "Select * from `contract register` where `Contract Name` ='"+contractName+"'";
        ResultSet rs = statement.executeQuery(sql);
        
        while(rs.next())
        {
            cr = new TransCR(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getDouble(6),rs.getDouble(7));
            
           
        }
        
        return cr;
    }
    //view all
     public Vector<TransCR> getContractRegister() throws SQLException
    {
       
        Vector<TransCR> listCr = new Vector<TransCR>();
        String sql = "Select * from `contract register`";
        ResultSet rs = statement.executeQuery(sql);
        
        while(rs.next())
        {
           TransCR cr = new TransCR(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getDouble(6),rs.getDouble(7));
            
        
            listCr.add(cr); 
        }
        return listCr;
    }
     
    //delete
      public int delete(String contractName) throws SQLException
    {
        String sql = "delete from `contract register` where `Contract Name`='"+contractName+"'";
         return statement.executeUpdate(sql);
    
    }
//close
     public void close() throws SQLException
    {
        statement.close();
        connection.close();
    }
}
