/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leezydaprogrammer.soft.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import leezydaprogrammer.soft.pojo.Accounts;

/**
 *
 * @author thand
 */
public class AccountsDao 
{
    private Connection connection;
    private Statement statement;
      
    //open
    public void openDbase() throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/drosdb","leezy","12345");
        statement = connection.createStatement();        
    }
    public Accounts login(String username,String password) throws SQLException
    {
         Accounts acc=null;
     String sql="Select * from `accounts` where `Username`= '"+username+"' and `Password`= '"+password+"'";
     ResultSet rs=  statement.executeQuery(sql);
     while(rs.next())
     {
        acc= new Accounts(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
     }      
       return acc;
    }
    //insert
     public int insert(Accounts account) throws SQLException
    {
        
      String sql="INSERT INTO `accounts`(`Username`,`First Name`,`Last Name`,`Email Address`,`Password`,`Role`,`Authorisation Level`,CellNo)" + " values('"+account.getUsername()+"','"+account.getFirstName()+"','"+account.getLastName()+"','"+account.getEmailAddress()+"','"+account.getPassword()+"','"+account.getRole()+"','"+account.getAuthorisationLevel()+"','"+account.getCellNo()+"')";
      
    return statement.executeUpdate(sql);
    }
     
   //update 
    public int update(Accounts account,String username) throws SQLException
    {
        String sql = "update `accounts` set `Username`='"+account.getUsername()+"', `First Name`='"+account.getFirstName()+"',`Last Name` ='"+account.getLastName()+"', `Email Address`='"+account.getEmailAddress()+"', `Password`='"+account.getPassword()+"', `Role`='"+account.getRole()+"', `Authorisation Level`='"+account.getAuthorisationLevel()+"', `CellNo`='"+account.getCellNo()+"' where `Username`= '"+username+"'";
         return statement.executeUpdate(sql);
    
    }
    //search Account
     public Accounts getAccount(String username) throws SQLException
    {
        Accounts acc=null;
        String sql = "Select * from `accounts` where `Username`='"+username+"'";
        ResultSet rs = statement.executeQuery(sql);
        while(rs.next())
        {
         acc= new Accounts(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
        }
        
        return acc;
    }
    //view all
     public Vector<Accounts> getAllAccounts() throws SQLException
    {
       
        Vector<Accounts> listAcc = new Vector<Accounts>();
        String sql = "Select * from `accounts`";
        ResultSet rs = statement.executeQuery(sql);
        
        while(rs.next())
        {
         Accounts acc= new Accounts(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
           
            listAcc.add(acc); 
        }
        return listAcc;
    }
     
    //delete
      public int delete(String username) throws SQLException
    {
        String sql = "Delete  from `accounts` where `Username`='"+username+"'";
        
         return statement.executeUpdate(sql);
         
    
    }
     
    //close
    public void close() throws SQLException
    {
        statement.close();
        connection.close();
    }
}
