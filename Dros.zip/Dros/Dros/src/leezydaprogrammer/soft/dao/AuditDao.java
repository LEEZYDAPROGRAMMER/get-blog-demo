/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leezydaprogrammer.soft.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import leezydaprogrammer.soft.dros.Audit;
import leezydaprogrammer.soft.pojo.Accounts;
import leezydaprogrammer.soft.pojo.AuditPojo;

/**
 *
 * @author thand
 */
public class AuditDao 
{
     private Connection connection;
    private Statement statement;
      
    //open
    public void openDbase() throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/drosdb","leezy","12345");
        statement = connection.createStatement();        
    }
    
     public int insertAudit(AuditPojo aud) throws SQLException
    {
        
      String sql="INSERT INTO `audit`(`ID`,`Username`,`Date`,`Status`,`Activity`)" + " values('"+aud.getId()+"','"+aud.getUsername()+"','"+aud.getDate()+"','"+aud.getStatus()+"','"+aud.getActivity()+"')";
      
    return statement.executeUpdate(sql);
    }
    
       public AuditPojo getAudit(String username) throws SQLException
    {
        AuditPojo aud=null;
        String sql = "Select * from `audit` where `Username`='"+username+"'";
        ResultSet rs = statement.executeQuery(sql);
        while(rs.next())
        {
         aud= new AuditPojo(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
        }
        
        return aud;
    }
             //close
    public void close() throws SQLException
    {
        statement.close();
        connection.close();
    }
     //view all
     public Vector<AuditPojo> getAllAudit(String username) throws SQLException
    {
       
        Vector<AuditPojo> listApp = new Vector<AuditPojo>();
        String sql = "Select * from `audit` where `Username`='"+username+"'";
        ResultSet rs = statement.executeQuery(sql);
        
        while(rs.next())
        {
         AuditPojo a = new AuditPojo(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
            
        
            listApp.add(a); 
        }
        return listApp;
    }
}
